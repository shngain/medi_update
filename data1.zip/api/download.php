<?php


// Database connection
$servername = "localhost";
$username = "root";
$password = "Admin@123#";
$dbname = "d-pharm";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the database
$sql = "SELECT 
            `id`, 
            `name`, 
            `quantity`, 
            `low_stock`, 
            `wholesale_rate`, 
            `selling_price`, 
            `vendor_id`, 
            `purpose`, 
            `description`, 
            `exp_date`, 
            `add_date`, 
            `created_by`
        FROM 
            `product`";

$result = $conn->query($sql);

// Arrays to hold products based on expiration status
$expiredProducts = array();
$aboutToExpireProducts = array();
$notExpiredProducts = array();

// Populate arrays based on expiration status
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $expDate = strtotime($row['exp_date']);
        $today = strtotime(date('Y-m-d'));
        $daysUntilExpiration = floor(($expDate - $today) / (60 * 60 * 24));

        if ($daysUntilExpiration < 0) {
            $expiredProducts[] = $row;
        } elseif ($daysUntilExpiration <= 30) {
            $aboutToExpireProducts[] = $row;
        } else {
            $notExpiredProducts[] = $row;
        }
    }
}

// Close connection
$conn->close();

// Create and populate CSV file for expired products
$expiredCsv = fopen('expired_products.csv', 'w');
if ($expiredCsv) {
    fputcsv($expiredCsv, array_keys($expiredProducts[0])); // Write headers
    foreach ($expiredProducts as $product) {
        fputcsv($expiredCsv, $product);
    }
    fclose($expiredCsv);
}

// Create and populate CSV file for about to expire products
$aboutToExpireCsv = fopen('about_to_expire_products.csv', 'w');
if ($aboutToExpireCsv) {
    fputcsv($aboutToExpireCsv, array_keys($aboutToExpireProducts[0])); // Write headers
    foreach ($aboutToExpireProducts as $product) {
        fputcsv($aboutToExpireCsv, $product);
    }
    fclose($aboutToExpireCsv);
}

// Create and populate CSV file for not expired products
$notExpiredCsv = fopen('not_expired_products.csv', 'w');
if ($notExpiredCsv) {
    fputcsv($notExpiredCsv, array_keys($notExpiredProducts[0])); // Write headers
    foreach ($notExpiredProducts as $product) {
        fputcsv($notExpiredCsv, $product);
    }
    fclose($notExpiredCsv);
}

// Set headers for file download
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="expired_products.csv"');
readfile('expired_products.csv');
unlink('expired_products.csv'); // Delete the file after download

header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="about_to_expire_products.csv"');
readfile('about_to_expire_products.csv');
unlink('about_to_expire_products.csv'); // Delete the file after download

header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="not_expired_products.csv"');
readfile('not_expired_products.csv');
unlink('not_expired_products.csv'); // Delete the file after download

exit;