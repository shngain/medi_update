
<?php
header("Access-Control-Allow-Origin: http://localhost");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$host = 'localhost';
$db   = 'd-pharm';
$user = 'root';
$pass = 'Admin@123#';
$charset = 'utf8mb4';

// Data to be inserted
$name = $_POST['name'];
$username =  $_POST['username'];
$password =  $_POST['password'];
$type =  $_POST['type'];
$status =  $_POST['status'];
$status =  $_POST['status'];
$tt =  $_POST['tt'];
$id =  $_POST['id'];

if($tt=='no'){
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
}
else{
    $hashedPassword = $password;
}

// Set up the DSN (Data Source Name)
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    // Create a PDO instance (connect to the database)
    $pdo = new PDO($dsn, $user, $pass, $options);
    
    // Prepare the SQL statement
    $stmt = $pdo->prepare("UPDATE `login` SET `name` = :name, `username` = :username, `password` = :password, `type` = :type, `status` = :status WHERE `id` = :id");
    
    // Bind parameters
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $hashedPassword);
    $stmt->bindParam(':type', $type);
    $stmt->bindParam(':status', $status);
    $stmt->bindParam(':id', $id);

    // Execute the statement
    $stmt->execute();
    
    // Return success response
    $response = [
        'status' => 'success',
        'message' => 'User updated successfully'
    ];
} catch (PDOException $e) {
    // Handle any errors
    $response = [
        'status' => 'error',
        'message' => 'Error: ' . $e->getMessage()
    ];
}

// Output the response in JSON format
header('Content-Type: application/json');
echo json_encode($response);
?>
