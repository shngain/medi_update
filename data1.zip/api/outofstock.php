<?php

// Database connection
$servername = "localhost";
$username = "root";
$password = "Admin@123#";
$dbname = "d-pharm";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT COUNT(*) AS zero_quantity_count FROM `product` WHERE `quantity` = 0;";
$result = $conn->query($sql);
if (!$result) {
    die("Query failed: " . $conn->error);
}

$zero_quantity_count = 0;
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $zero_quantity_count = $row['zero_quantity_count'];
} else {
    $zero_quantity_count = 0;
}

$conn->close();

header('Content-Type: application/json');
echo json_encode(['zero_quantity_count' => $zero_quantity_count]);
?>