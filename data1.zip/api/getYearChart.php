<?php
header("Access-Control-Allow-Origin: http://localhost");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
$dbHost = 'localhost';
$dbUsername = 'root';
$password = "Admin@123#";
$dbName = 'd-pharm';
try {
    $pdo = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUsername, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $pdo->query("SELECT YEAR(datetime) AS year_number, COALESCE(SUM(actual_amount), 0) AS total_actual_amount,COALESCE(SUM(whole_sale_total), 0) AS whole_amount FROM bills WHERE YEAR(datetime) <= YEAR(CURRENT_DATE()) GROUP BY YEAR(datetime);");
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    header('Content-Type: application/json');
    echo json_encode($data);
} else {
    http_response_code(405);
    echo json_encode(array("message" => "Method Not Allowed"));
}
?>