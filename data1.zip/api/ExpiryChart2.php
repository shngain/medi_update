<?php
header("Access-Control-Allow-Origin: http://localhost");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
$dbHost = 'localhost';
$dbUsername = 'root';
$password = "Admin@123#";
$dbName = 'd-pharm';
try {
    $pdo = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUsername, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $pdo->query("SELECT 
        statuses.`status` AS `expiry_status`,
        IFNULL(products_count.`product_count`, 0) AS `product_count`
    FROM (
        SELECT 'Expired' AS `status`
        UNION ALL
        SELECT 'WithinThisMonth' AS `status`
        UNION ALL
        SELECT 'Within2Months' AS `status`
        UNION ALL
        SELECT 'Within3Months' AS `status`
    ) AS statuses
    LEFT JOIN (
        SELECT 
            CASE
                WHEN `exp_date` < CURDATE() THEN 'Expired'
                WHEN `exp_date` >= CURDATE() AND `exp_date` < DATE_ADD(CURDATE(), INTERVAL 1 MONTH) THEN 'WithinThisMonth'
                WHEN `exp_date` >= CURDATE() AND `exp_date` < DATE_ADD(CURDATE(), INTERVAL 2 MONTH) THEN 'Within2Months'
                WHEN `exp_date` >= CURDATE() AND `exp_date` < DATE_ADD(CURDATE(), INTERVAL 3 MONTH) THEN 'Within3Months'
            END AS `expiry_status`,
            COUNT(*) AS `product_count`
        FROM 
            `product`
        GROUP BY 
            `expiry_status`
    ) AS products_count ON statuses.`status` = products_count.`expiry_status`");
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    header('Content-Type: application/json');
    echo json_encode($data);
} else {
    http_response_code(405);
    echo json_encode(array("message" => "Method Not Allowed"));
}
?>
