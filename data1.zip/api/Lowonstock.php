<?php

// Database connection
$servername = "localhost";
$username = "root";
$password = "Admin@123#";
$dbname = "d-pharm";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT COUNT(*) AS low_stock_count FROM `product` WHERE `quantity` < `low_stock`;";
$result = $conn->query($sql);
if (!$result) {
    die("Query failed: " . $conn->error);
}

$low_stock_count = 0;
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $low_stock_count = $row['low_stock_count'];
} else {
    $low_stock_count = 0;
}

$conn->close();

header('Content-Type: application/json');
echo json_encode(['low_stock_count' => $low_stock_count]);
?>