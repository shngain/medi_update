<?php

// Database connection
$servername = "localhost";
$username = "root";
$password = "Admin@123#";
$dbname = "d-pharm";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$today = date("Y-m-d");
$sql = "SELECT SUM(`actual_amount`) AS `total_sale_amount` FROM `bills` WHERE DATE(`datetime`) = '$today'";
$result = $conn->query($sql);

if (!$result) {
    // Query failed, print error message
    die("Query failed: " . $conn->error);
}

$totalSaleAmount = 0;
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalSaleAmount = $row['total_sale_amount'];
} else {
    $totalSaleAmount = 0;
}

$conn->close();

header('Content-Type: application/json');
echo json_encode(['total_sale_amount' => $totalSaleAmount]);
?>