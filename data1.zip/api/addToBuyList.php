<?php
// Assuming you're using PDO for database operations
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
$host = 'localhost';
$dbname = 'd-pharm';
$username = 'root';
$password = "Admin@123#";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Assuming you have a table named 'buy_list' with columns 'product_name', 'vendor_name', 'quantity', and 'date_added'
    $sql = "INSERT INTO buy_list (pid, vid, quantity, date) VALUES (:pid, :vid, :quantity, :dateAdded)";
    $stmt = $pdo->prepare($sql);
    
    // Extract data from the POST request
    $pid = $_POST['pid'];
    $vid = $_POST['vid'];
    $quantity = $_POST['quantity'];
    // Get the current date and time
    $dateAdded = date('Y-m-d H:i:s');
    
    // Bind parameters and execute the statement
    $stmt->bindParam(':pid', $pid);
    $stmt->bindParam(':vid', $vid);
    $stmt->bindParam(':quantity', $quantity);
    $stmt->bindParam(':dateAdded', $dateAdded);
    $stmt->execute();

    // Return success response
    echo json_encode(['success' => true]);
} catch(PDOException $e) {
    // Return error response
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
