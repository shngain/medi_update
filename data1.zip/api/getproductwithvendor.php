<?php
header("Access-Control-Allow-Origin: http://localhost");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
$dbHost = 'localhost';
$dbUsername = 'root';
$password = "Admin@123#";
$dbName = 'd-pharm';
try {
    $pdo = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUsername, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $pdo->query("SELECT *,v.name as vname,p.name as pname,p.id as pid FROM product as p ,vendor as v where p.vendor_id=v.id");
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    header('Content-Type: application/json');
    echo json_encode($data);
} else {
    http_response_code(405);
    echo json_encode(array("message" => "Method Not Allowed"));
}
?>