<?php
$host = 'localhost';
$dbname = 'd-pharm';
$username = 'root';
$password = "Admin@123#";
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $keyword = isset($_GET['q']) ? $_GET['q'] : '';

    try {
        $sql = "SELECT * FROM product WHERE name LIKE :keyword";
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':keyword', '%' . $keyword . '%');
        $stmt->execute();
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($products);
    } catch (PDOException $e) {
        echo json_encode(array("message" => "Failed to retrieve products: " . $e->getMessage()));
    }
}
?>