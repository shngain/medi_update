<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
$host = 'localhost';
$dbname = 'd-pharm';
$username = 'root';
$password = "Admin@123#";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $discount = $_POST['discount'];
    $transaction_id = $_POST['transaction_id'];
    $total_amount = $_POST['total_amount'];
    $actual_amount = $_POST['actual_amount'];
    $W_amount = $_POST['wholesale'];
    $currentDateTime = date('Y-m-d H:i:s');
    $product_list = json_decode($_POST['product_list'], true); // Decode the JSON string into an associative array

    $sql = "INSERT INTO bills (datetime,discount,transaction_id,total_amount,actual_amount,whole_sale_total	) 
            VALUES (:datetime,:discount,:transaction_id,:total_amount,:actual_amount,:whole_sale_total)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':datetime', $currentDateTime);
    $stmt->bindParam(':discount', $discount);
    $stmt->bindParam(':transaction_id', $transaction_id);
    $stmt->bindParam(':total_amount', $total_amount);
    $stmt->bindParam(':actual_amount', $actual_amount);
    $stmt->bindParam(':whole_sale_total', $W_amount);
    try {
        $pdo->beginTransaction();
        $stmt->execute();
        $bill_id = $pdo->lastInsertId();
        foreach ($product_list as $product) {
            $product_id = $product['productId'];
            $productQty = $product['productQty'];
            $name = $product['productName'];
            $price = $product['productTprice'];

            $updateSql = "UPDATE product SET quantity = quantity - :productQty WHERE id = :product_id";
            $updateStmt = $pdo->prepare($updateSql);
            $updateStmt->bindParam(':productQty', $productQty);
            $updateStmt->bindParam(':product_id', $product_id);
            $updateStmt->execute();


            $sql = "INSERT INTO bill_product (product_id, quantity, transaction_id,name,price) 
                    VALUES (:product_id, :quantity, :transaction_id,:name,:price)";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':product_id', $product_id);
            $stmt->bindParam(':quantity', $productQty);
            $stmt->bindParam(':transaction_id', $transaction_id);
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':price', $price);
            $stmt->execute();
        }
        $pdo->commit();
        echo json_encode(array("message" => "Product added successfully"));
    } catch (PDOException $e) {
        $pdo->rollback();
        echo json_encode(array("message" => "Failed to add product: " . $e->getMessage()));
    }
}
?>