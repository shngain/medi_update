<?php

// Database connection
$servername = "localhost";
$username = "root";
$password = "Admin@123#";
$dbname = "d-pharm";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to find products with low stock
$sql = "SELECT p.*,v.name as vname FROM product p,vendor v WHERE p.vendor_id = v.id and  p.quantity = 0 order by v.name";
$result = $conn->query($sql);
if (!$result) {
    die("Query failed: " . $conn->error);
}

// Fetch all products with low stock
$low_stock_products = [];
while ($row = $result->fetch_assoc()) {
    $low_stock_products[] = $row;
}

$conn->close();

// Output the result as JSON
header('Content-Type: application/json');
echo json_encode(['low_stock_products' => $low_stock_products]);
?>