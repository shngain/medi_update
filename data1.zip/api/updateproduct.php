<?php
// Database configuration
$host = 'localhost';
$dbname = 'd-pharm';
$username = 'root';
$password = "Admin@123#";

// Create a PDO instance
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Handle POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the POST request
    $id = $_POST['id']; // Assuming you also pass the ID of the product to update
    $name = $_POST['name'];
    $sellingPrice = $_POST['sellingPrice'];
    $quantity = $_POST['quantity'];
    $lowStock = $_POST['lowStock'];
    $costPrice = $_POST['costPrice'];
    $preferredVendor = $_POST['preferredVendor'];
    $additionalNotes = $_POST['additionalNotes'];
    $expiryDate = $_POST['expiryDate'];
    $purpose = $_POST['purpose'];

    // Prepare SQL statement
    $sql = "UPDATE product SET 
            name = :name, 
            selling_price = :sellingPrice, 
            quantity = :quantity, 
            low_stock = :lowStock, 
            wholesale_rate = :costPrice, 
            vendor_id = :preferredVendor, 
            description = :additionalNotes, 
            exp_date = :expiryDate, 
            purpose = :purpose 
            WHERE id = :id";
    $stmt = $pdo->prepare($sql);

    // Bind parameters
    $stmt->bindParam(':id', $id); // Bind ID
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':sellingPrice', $sellingPrice);
    $stmt->bindParam(':quantity', $quantity);
    $stmt->bindParam(':lowStock', $lowStock);
    $stmt->bindParam(':costPrice', $costPrice);
    $stmt->bindParam(':preferredVendor', $preferredVendor);
    $stmt->bindParam(':additionalNotes', $additionalNotes);
    $stmt->bindParam(':expiryDate', $expiryDate);
    $stmt->bindParam(':purpose', $purpose);

    // Execute the statement
    try {
        $stmt->execute();
        echo json_encode(array("message" => "Product updated successfully"));
    } catch (PDOException $e) {
        echo json_encode(array("message" => "Failed to update product: " . $e->getMessage()));
    }
}
?>