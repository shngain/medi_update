<?php
// Database configuration
$host = 'localhost';
$dbname = 'd-pharm';
$username = 'root';
$password = "Admin@123#";

// Create a PDO instance
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Check if the product ID is provided in the request
if (isset($_GET['id'])) {
    $productId = $_GET['id'];

    // Prepare SQL statement
    $sql = "DELETE FROM product WHERE id = :id";
    $stmt = $pdo->prepare($sql);

    // Bind parameters
    $stmt->bindParam(':id', $productId);

    // Execute the statement
    try {
        $stmt->execute();
        echo json_encode(array("message" => "Product deleted successfully"));
    } catch (PDOException $e) {
        echo json_encode(array("message" => "Failed to delete product: " . $e->getMessage()));
    }
} else {
    // If product ID is not provided in the request, return an error message
    echo json_encode(array("message" => "Product ID is required"));
}
?>
