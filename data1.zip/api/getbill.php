<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
$dbHost = 'localhost';
$dbUsername = 'root';
$password = "Admin@123#";
$dbName = 'd-pharm';
try {
    $pdo = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUsername, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Define your API endpoint
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $stmt = $pdo->prepare("SELECT * FROM bills RIGHT JOIN bill_product ON bills.transaction_id = bill_product.transaction_id WHERE bills.transaction_id=:id");
        $stmt->bindValue(':id', $id);
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        header('Content-Type: application/json');
        echo json_encode($data);
    } else {
        http_response_code(400); // Bad Request
        echo json_encode(array("message" => "ID parameter is missing"));
    }
} else {
    // Handle unsupported HTTP methods
    http_response_code(405);
    echo json_encode(array("message" => "Method Not Allowed"));
}
?>