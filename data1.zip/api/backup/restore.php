<?php
header('Content-Type: application/json');

// Database configuration
$host = 'localhost';
$user = 'root';
$password = 'Admin@123#';
$database = 'd-pharm';

if ($_FILES['backupFile']['error'] === UPLOAD_ERR_OK) {
    $backupFile = $_FILES['backupFile']['tmp_name'];
    $mysqlPath = 'C:\\xampp\\mysql\\bin\\mysql.exe';

    $command = "{$mysqlPath} --host={$host} --user={$user} --password={$password} {$database} < {$backupFile} 2>&1";
    exec($command, $output, $result);

    if ($result === 0) {
        $response = [
            "status" => "success",
            "message" => "Restore successful!"
        ];
    } else {
        $response = [
            "status" => "error",
            "message" => "Restore failed!",
            "command" => $command,
            "output" => implode("\n", $output)
        ];
    }
} else {
    $response = [
        "status" => "error",
        "message" => "Failed to upload the file."
    ];
}

echo json_encode($response);
?>