<?php
header('Content-Type: application/json');

// Database configuration
$host = 'localhost';
$user = 'root';
$password = 'Admin@123#';
$database = 'd-pharm';

$date = date('Y-m-d_H-i-s');
$backupFile = __DIR__ . "\\backup_{$database}_{$date}.sql";
$mysqldumpPath = 'C:\\xampp\\mysql\\bin\\mysqldump.exe';

$command = "{$mysqldumpPath} --host={$host} --user={$user} --password={$password} {$database} > {$backupFile} 2>&1";
exec($command, $output, $result);

if ($result === 0) {
    $response = [
        "status" => "success",
        "message" => "Backup successful! File saved as {$backupFile}",
        "file" => $backupFile
    ];
} else {
    $response = [
        "status" => "error",
        "message" => "Backup failed!",
        "command" => $command,
        "output" => implode("\n", $output)
    ];
}

echo json_encode($response);
?>