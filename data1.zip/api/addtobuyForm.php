<?php
header('Content-Type: application/json');

// Database connection details
$hostname = 'localhost';
$dbname = 'd-pharm';
$username = 'root';
$password = 'Admin@123#';

try {
    $pdo = new PDO("mysql:host=$hostname;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $pid = $_POST['pname'];
    $vid = $_POST['vendorname'];
    $quantity = $_POST['quantity'];
    $date = date('Y-m-d H:i:s'); 

    $sql = "INSERT INTO `buy_list`(`pid`, `vid`, `quantity`, `date`) VALUES (:pid, :vid, :quantity, :date)";

    $stmt = $pdo->prepare($sql);

    $stmt->bindParam(':pid', $pid);
    $stmt->bindParam(':vid', $vid);
    $stmt->bindParam(':quantity', $quantity);
    $stmt->bindParam(':date', $date);

    $stmt->execute();

    echo json_encode(['status' => 'success', 'message' => 'New record created successfully']);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Error: ' . $e->getMessage()]);
}

$pdo = null;
?>
