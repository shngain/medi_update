<?php
// Define the URL of the ZIP file
$zipUrl = $_GET['u'];

// Use the system's temporary directory to save the downloaded ZIP file
$zipFilePath = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'sample.zip';

// Define the extraction path (set to your desired directory)
$extractPath = 'C:\\xampp\\htdocs\\D-pharm\\'; // Make sure to use double backslashes for Windows paths

// Function to download the ZIP file
function downloadZipFile($url, $path) {
    $fp = fopen($path, 'w+');
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_FILE, $fp);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_exec($ch);
    curl_close($ch);
    fclose($fp);
}

// Function to extract the ZIP file
function extractZipFile($zipPath, $extractTo) {
    $zip = new ZipArchive;
    if ($zip->open($zipPath) === TRUE) {
        $zip->extractTo($extractTo);
        $zip->close();
        return true;
    } else {
        return false;
    }
}

// Download the ZIP file
downloadZipFile($zipUrl, $zipFilePath);

// Extract the ZIP file
if (extractZipFile($zipFilePath, $extractPath)) {
    // Optionally, delete the ZIP file after extraction
    unlink($zipFilePath);
    echo 'Done';
} else {
    echo 'Failed to extract the ZIP file.';
}
?>
