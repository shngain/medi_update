<?php
// Database configuration
$host = 'localhost';
$dbname = 'd-pharm';
$username = 'root';
$password = 'Admin@123#';

// Create a PDO instance
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Handle POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the POST request
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $description = $_POST['description'];
    $address = $_POST['address'];
    $status = isset($_POST['status']) ? 1 : 0;

    // Prepare SQL statement
    $sql = "INSERT INTO vendor (name, email, phone, description, address, status) VALUES (:name, :email, :phone, :description, :address, :status)";
    $stmt = $pdo->prepare($sql);

    // Bind parameters
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':address', $address);
    $stmt->bindParam(':status', $status);

    // Execute the statement
    try {
        $stmt->execute();
        echo json_encode(array("message" => "Vendor added successfully"));
    } catch (PDOException $e) {
        echo json_encode(array("message" => "Failed to add vendor: " . $e->getMessage()));
    }
}
?>