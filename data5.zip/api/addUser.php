
<?php
header("Access-Control-Allow-Origin: http://localhost");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$host = 'localhost';
$db   = 'd-pharm';
$user = 'root';
$pass = 'Admin@123#';
$charset = 'utf8mb4';

// Data to be inserted
$name = $_POST['name'];
$username =  $_POST['username'];
$password =  $_POST['password'];
$type =  $_POST['type'];
$status =  $_POST['status'];
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Set up the DSN (Data Source Name)
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    // Create a PDO instance (connect to the database)
    $pdo = new PDO($dsn, $user, $pass, $options);
    
    // Prepare the SQL statement
    $stmt = $pdo->prepare("INSERT INTO `login` (`name`, `username`, `password`, `type`, `status`) VALUES (:name, :username, :password, :type, :status)");
    
    // Bind parameters
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $hashedPassword);
    $stmt->bindParam(':type', $type);
    $stmt->bindParam(':status', $status);
    
    // Execute the statement
    $stmt->execute();
    
    // Return success response
    $response = [
        'status' => 'success',
        'message' => 'User added successfully'
    ];
} catch (PDOException $e) {
    // Handle any errors
    $response = [
        'status' => 'error',
        'message' => 'Error: ' . $e->getMessage()
    ];
}

// Output the response in JSON format
header('Content-Type: application/json');
echo json_encode($response);
?>
