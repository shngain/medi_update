<?php
$dsn = "mysql:host=localhost;dbname=d-pharm";
$username = "root";
$password = "Admin@123#";

$response = array();

try {
    $pdo = new PDO($dsn, $username, $password);
    
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $name = $_POST['name'];
    $datetime = date("Y-m-d H:i:s"); 
    $fileid = $_POST['fileid'];

    $query = "INSERT INTO `backup`( `name`, `datetime`, `fileid`) VALUES ( ?, ?, ?)";

    $stmt = $pdo->prepare($query);

    $stmt->bindParam(1, $name);
    $stmt->bindParam(2, $datetime);
    $stmt->bindParam(3, $fileid);

    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $response['success'] = true;
        $response['message'] = "Data inserted successfully!";
    } else {
        $response['success'] = false;
        $response['message'] = "Error inserting data";
    }
} catch(PDOException $e) {
    $response['success'] = false;
    $response['message'] = "Error: " . $e->getMessage();
}

$pdo = null;

header('Content-Type: application/json');
echo json_encode($response);
?>
