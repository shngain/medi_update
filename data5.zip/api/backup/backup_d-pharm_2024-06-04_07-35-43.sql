-- MariaDB dump 10.17  Distrib 10.4.6-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: d-pharm
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backup`
--

DROP TABLE IF EXISTS `backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `datetime` text NOT NULL,
  `fileid` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup`
--

LOCK TABLES `backup` WRITE;
/*!40000 ALTER TABLE `backup` DISABLE KEYS */;
INSERT INTO `backup` VALUES (1,'backup_20240527_092809.zip','2024-05-27 11:28:11','1AJy7JKBeLWipFgNpGs-usSKg-v_Qlwu2'),(2,'backup_20240527_093557.zip','2024-05-27 11:35:59','1qxYbQZvmoMrjp-QKhgeW56N2iifZRRyn'),(3,'backup_20240527_110136.zip','2024-05-27 13:01:39','1hv1dFcR7UvaWJxIqNTgdW2CEPpcAbSPI');
/*!40000 ALTER TABLE `backup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill_product`
--

DROP TABLE IF EXISTS `bill_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bill_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` varchar(20) NOT NULL,
  `name` varchar(90) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `price` varchar(60) NOT NULL,
  `transaction_id` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill_product`
--

LOCK TABLES `bill_product` WRITE;
/*!40000 ALTER TABLE `bill_product` DISABLE KEYS */;
INSERT INTO `bill_product` VALUES (1,'1','zerodol','10','10','DMP-1713942956622'),(2,'1','zerodol','10','10','DMP-1713942993191'),(3,'1','zerodol','20','10','DMP-1713942993191'),(4,'1','zerodol','12','10','DMP-1713983805850'),(5,'1','zerodol','10','10','DMP-1713984284760'),(6,'1','zerodol','30','10','DMP-1713986378598'),(7,'1','zerodol','10','10','DMP-1713986378598'),(8,'1','zerodol','30','300','DMP-1713986552679'),(9,'1','zerodol','2','20','DMP-1713986552679'),(10,'1','zerodol','20','200','DMP-1714019130227'),(11,'1','zerodol','20','200','DMP-1714019161349'),(12,'2','Dawai','2','320','DMP-1714451417769'),(13,'1','zerodol','2','20','DMP-1714451417769'),(14,'2','Dawai','2','320','DMP-1714452236686'),(15,'1','zerodol','3','30','DMP-1714452236686'),(16,'3','Dawai 2','5','550','DMP-1714452236686'),(17,'1','zerodol','1','10','DMP-1714991190916'),(18,'1','zerodol','1','10','DMP-1714991345758'),(19,'5','test','1','1','DMP-1715065822103'),(20,'5','test','1','1','DMP-1715065839775'),(21,'1','zerodol','150','1500','DMP-1715323358414'),(22,'1','zerodol','0','0','DMP-1715585295067'),(23,'10','zerodol','1','150','DMP-1715858584481'),(24,'14','zerodol','1','1','DMP-1716273838727'),(25,'15','Zerodol','1','1','DMP-1716876725124'),(26,'41','Zerodol','1','1','DMP-1717060372499'),(27,'15','Zerodol','151','45000','DMP-1717135340559'),(28,'12','del','1','250','DMP-1717152486527'),(29,'12','del','1','250','DMP-1717153071418');
/*!40000 ALTER TABLE `bill_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bills`
--

DROP TABLE IF EXISTS `bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `c_name` varchar(200) DEFAULT NULL,
  `c_phone` varchar(50) DEFAULT NULL,
  `c_address` varchar(250) DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  `total_amount` double DEFAULT NULL,
  `actual_amount` double DEFAULT NULL,
  `whole_sale_total` double NOT NULL,
  `discount` double DEFAULT NULL,
  `tax` double DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `transaction_id` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bills`
--

LOCK TABLES `bills` WRITE;
/*!40000 ALTER TABLE `bills` DISABLE KEYS */;
INSERT INTO `bills` VALUES (2,'','','','2024-04-24 09:15:56',100,100,50,0,0,'','DMP-1713942956622'),(3,'','','','2024-04-24 09:16:33',300,300,20,0,0,'','DMP-1713942993191'),(4,'','','','2024-04-24 20:36:45',120,120,10,0,0,'','DMP-1713983805850'),(5,'','','','2024-04-24 20:44:44',100,100,80,0,0,'','DMP-1713984284760'),(8,'','','','2024-04-24 21:19:38',400,400,30,0,0,'','DMP-1713986378598'),(9,'','','','2024-04-24 21:22:32',320,320,80,0,0,'','DMP-1713986552679'),(10,NULL,NULL,NULL,'2024-04-25 06:25:30',200,200,80,0,NULL,NULL,'DMP-1714019130227'),(11,NULL,NULL,NULL,'2024-04-25 06:26:01',200,200,50,0,NULL,NULL,'DMP-1714019161349'),(12,NULL,NULL,NULL,'2024-04-30 06:30:17',340,340,50,0,NULL,NULL,'DMP-1714451417769'),(13,NULL,NULL,NULL,'2024-04-30 06:43:56',900,900,50,0,NULL,NULL,'DMP-1714452236686'),(14,NULL,NULL,NULL,'2024-05-06 12:26:30',10,10,20,0,NULL,NULL,'DMP-1714991190916'),(15,NULL,NULL,NULL,'2024-05-06 12:29:05',10,10,10,0,NULL,NULL,'DMP-1714991345758'),(16,NULL,NULL,NULL,'2024-05-07 09:10:22',1,1,10,0,NULL,NULL,'DMP-1715065822103'),(17,NULL,NULL,NULL,'2024-05-07 09:10:39',1,1,10,0,NULL,NULL,'DMP-1715065839775'),(18,NULL,NULL,NULL,'2024-05-07 09:54:20',0,0,20,0,NULL,NULL,'DMP-1715068460685'),(19,NULL,NULL,NULL,'2024-05-10 08:42:38',1500,1500,750,0,NULL,NULL,'DMP-1715323358414'),(20,NULL,NULL,NULL,'2024-05-13 09:28:15',0,0,0,0,NULL,NULL,'DMP-1715585295067'),(21,NULL,NULL,NULL,'2024-05-16 13:23:04',150,150,100,0,NULL,NULL,'DMP-1715858584481'),(22,NULL,NULL,NULL,'2024-05-21 08:43:58',1,1,1,0,NULL,NULL,'DMP-1716273838727'),(23,NULL,NULL,NULL,'2024-05-28 08:12:05',1,1,1,0,NULL,NULL,'DMP-1716876725124'),(24,NULL,NULL,NULL,'2024-05-30 11:12:52',1,1,1,0,NULL,NULL,'DMP-1717060372499'),(25,NULL,NULL,NULL,'2024-05-31 07:45:36',0,0,0,0,NULL,NULL,'DMP-1717134336894'),(26,NULL,NULL,NULL,'2024-05-31 08:02:20',45000,45000,22500,0,NULL,NULL,'DMP-1717135340559'),(27,NULL,NULL,NULL,'2024-05-31 12:48:06',250,250,150,0,NULL,NULL,'DMP-1717152486527'),(28,NULL,NULL,NULL,'2024-05-31 12:57:51',250,250,150,0,NULL,NULL,'DMP-1717153071418');
/*!40000 ALTER TABLE `bills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `buy_list`
--

DROP TABLE IF EXISTS `buy_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buy_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` varchar(225) DEFAULT NULL,
  `vid` varchar(225) DEFAULT NULL,
  `quantity` varchar(225) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buy_list`
--

LOCK TABLES `buy_list` WRITE;
/*!40000 ALTER TABLE `buy_list` DISABLE KEYS */;
INSERT INTO `buy_list` VALUES (25,'del','Pynshngainlang  Marbaniang','8','2024-05-30'),(26,'del','Pynshngainlang  Marbaniang','5','2024-05-31'),(27,'del','Pynshngainlang  Marbaniang','4','2024-05-31'),(28,'del','Pynshngainlang  Marbaniang','1','2024-05-31'),(29,'Zerodol','Pynshngainlang  Marbaniang','1','2024-05-31'),(30,'Zerodol','Pynshngainlang  Marbaniang','1','2024-05-31'),(31,'del','Pynshngainlang  Marbaniang','1','2024-05-31'),(32,'Zerodol','Pynshngainlang  Marbaniang','1','2024-05-31'),(33,'del','Pynshngainlang  Marbaniang','1','2024-05-31');
/*!40000 ALTER TABLE `buy_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(250) NOT NULL,
  `type` varchar(150) NOT NULL,
  `status` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES (1,'Sanjiban3','sanjiban','$2y$10$pr7gl.Br1wlws7HJt.vzuOnS.fBJCvZ9BaiQeYMJrwRx/NQgcH6me','admin','false'),(2,'user','user','$2y$10$pr7gl.Br1wlws7HJt.vzuOnS.fBJCvZ9BaiQeYMJrwRx/NQgcH6me','user','active');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `quantity` bigint(20) NOT NULL,
  `low_stock` bigint(20) NOT NULL,
  `wholesale_rate` double NOT NULL,
  `selling_price` double NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `purpose` varchar(250) NOT NULL,
  `description` varchar(500) NOT NULL,
  `exp_date` datetime DEFAULT NULL,
  `add_date` datetime DEFAULT NULL,
  `created_by` varchar(45) DEFAULT NULL,
  `shelfArea` varchar(255) DEFAULT NULL,
  `typeOfMedicine` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (12,'del',148,100,150,250,3,'Fever,flu','test','2025-06-05 00:00:00','2024-05-16 00:00:00',NULL,'A1','ethical',''),(15,'Zerodol',150,100,150,300,3,'Cancer, Heart Attach','test','2024-04-09 00:00:00','2024-05-16 00:00:00',NULL,'1','ethical',''),(39,'Dolo',150,10,150,250,2,'Fever,flu','Test','2024-08-05 00:00:00','2024-05-27 00:00:00',NULL,'1','ethical',''),(40,'Dolo',150,10,150,250,2,'Fever,flu','Test','2024-05-31 00:00:00','2024-05-27 00:00:00',NULL,'1','ethical','New_2'),(41,'Zerodol',150,1,1,1,3,'Cancer, Heart Attach','test','2024-07-17 00:00:00','2024-05-16 00:00:00',NULL,'1','ethical','New_2'),(42,'rwrw',1212,1212,1212,12121,2,'rwrw','fafaasaf','0002-02-02 00:00:00','2024-05-10 00:00:00',NULL,'1','ethical','');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendor`
--

DROP TABLE IF EXISTS `vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(250) NOT NULL,
  `description` varchar(500) NOT NULL,
  `address` varchar(500) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `created_by` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendor`
--

LOCK TABLES `vendor` WRITE;
/*!40000 ALTER TABLE `vendor` DISABLE KEYS */;
INSERT INTO `vendor` VALUES (2,'Shngain','mpynzhng@gmail.com','9089026095','I am a good Vendor','Mairang','1',NULL),(3,'Pynshngainlang  Marbaniang','mpynzhng@gmail.com','9089026095','Pyndengumiong Mairang','Dongbir','1',NULL),(4,'Raymond','raymond@gmail.com','9089026095','Pyndengumiong Mairang','Dongbir','1',NULL),(5,'Pynshngainlang  Marbaniang','mpynzhng@gmail.com','','Pyndengumiong Mairang','Dongbir','1',NULL),(6,'Pynshngainlang  Marbaniang','mpynzhng@gmail.com','','Pyndengumiong Mairang','Dongbir','1',NULL),(7,'Pynshngainlang  Marbaniang','mpynzhng@gmail.com','','Pyndengumiong Mairang','Dongbir','1',NULL),(8,'Pynshngainlang  Marbaniang','mpynzhng@gmail.com','9089026095','Pyndengumiong Mairang','Dongbir','1',NULL),(9,'test','mpynzhng@gmail.com','9089026095','test','Pyndengumiong Mairang\r\nDongbir','1',NULL);
/*!40000 ALTER TABLE `vendor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-04 11:05:43
