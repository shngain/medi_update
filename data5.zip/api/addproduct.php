<?php
// Database configuration
$host = 'localhost';
$dbname = 'd-pharm';
$username = 'root';
$password = 'Admin@123#';

// Create a PDO instance
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Handle POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the POST request
    $name = $_POST['name'];
    $sellingPrice = $_POST['sellingPrice'];
    $quantity = $_POST['quantity'];
    $lowStock = $_POST['lowStock'];
    $costPrice = $_POST['costPrice'];
    $preferredVendor = $_POST['preferredVendor'];
    $additionalNotes = $_POST['additionalNotes'];
    $expiryDate = $_POST['expiryDate'];
    $purpose = $_POST['purpose'];
    $shelfArea = $_POST['shelfArea'];
    $typeOfMedicine = $_POST['typeOfMedicine'];
    $add_date = $_POST['add_date'];
    
    // Get current date and time
    $currentDateTime = date('Y-m-d H:i:s');

    // Check if the product already exists
    $existingProductQuery = "SELECT * FROM product WHERE name = :name AND vendor_id = :preferredVendor AND exp_date = :expiryDate";
    $existingStmt = $pdo->prepare($existingProductQuery);
    $existingStmt->bindParam(':name', $name);
    $existingStmt->bindParam(':preferredVendor', $preferredVendor);
    $existingStmt->bindParam(':expiryDate', $expiryDate);
    $existingStmt->execute();
    $existingProduct = $existingStmt->fetch();

    $existingProductQuery2 = "SELECT count(*) as count FROM product WHERE name = :name AND vendor_id = :preferredVendor";
    $existingStmt2 = $pdo->prepare($existingProductQuery2);
    $existingStmt2->bindParam(':name', $name);
    $existingStmt2->bindParam(':preferredVendor', $preferredVendor);
    $existingStmt2->execute();
    $existingProduct2 = $existingStmt2->fetch();
    $existingProductCount = $existingStmt2->rowCount();

    $status = '';
    if ($existingProduct2['count'] > 0) {
        // Append the count to the 'New_' string
        $status .= 'New_' . ($existingProduct2['count'] + 1);
    }

    // echo($existingProductCount);
    // echo($status);
    // echo json_encode($existingProduct2);

    if ($existingProduct) {
        // Product exists, update the record
        $sql = "UPDATE product SET selling_price = :sellingPrice, quantity = :quantity, low_stock = :lowStock, wholesale_rate = :costPrice, description = :additionalNotes, purpose = :purpose, add_date = :add_date,shelfArea= :shelfArea,typeOfMedicine=:typeOfMedicine WHERE name = :name AND vendor_id = :preferredVendor AND exp_date = :expiryDate";
        $stmt = $pdo->prepare($sql);
    }
    else if($existingProduct2['count'] > 0){
        $sql = "INSERT INTO product (name, selling_price, quantity, low_stock, wholesale_rate, vendor_id, description, exp_date, purpose, add_date,shelfArea,typeOfMedicine,status) 
        VALUES (:name,:sellingPrice,:quantity,:lowStock,:costPrice,:preferredVendor,:additionalNotes,:expiryDate,:purpose, :add_date,:shelfArea,:typeOfMedicine,'$status')";
        $stmt = $pdo->prepare($sql);
    }
    else {
        // Product does not exist, insert a new record
        $sql = "INSERT INTO product (name, selling_price, quantity, low_stock, wholesale_rate, vendor_id, description, exp_date, purpose, add_date,shelfArea,typeOfMedicine,status) 
                VALUES (:name,:sellingPrice,:quantity,:lowStock,:costPrice,:preferredVendor,:additionalNotes,:expiryDate,:purpose, :add_date,:shelfArea,:typeOfMedicine,'$status')";
        $stmt = $pdo->prepare($sql);
    }

    // Bind parameters
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':sellingPrice', $sellingPrice);
    $stmt->bindParam(':quantity', $quantity);
    $stmt->bindParam(':lowStock', $lowStock);
    $stmt->bindParam(':costPrice', $costPrice);
    $stmt->bindParam(':preferredVendor', $preferredVendor);
    $stmt->bindParam(':additionalNotes', $additionalNotes);
    $stmt->bindParam(':expiryDate', $expiryDate);
    $stmt->bindParam(':purpose', $purpose);
    $stmt->bindParam(':add_date', $add_date); // Bind current date/time
    $stmt->bindParam(':shelfArea', $shelfArea); // Bind current date/time
    $stmt->bindParam(':typeOfMedicine', $typeOfMedicine); // Bind current date/time
    
    
    // Execute the statement
    try {
        if ($existingProduct) {
            $stmt->execute();
            echo json_encode(array("message" => "Product updated successfully"));
        } else if($existingProduct2['count'] > 0){
            $stmt->execute();
            echo json_encode(array("message" => "Product added successfully"));
        }else{
            $stmt->execute();
            echo json_encode(array("message" => "Product added successfully"));
        }
    } catch (PDOException $e) {
        echo json_encode(array("message" => "Failed to add/update product: " . $e->getMessage()));
    }
}
?>
