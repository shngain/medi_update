<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
$dbHost = 'localhost';
$dbUsername = 'root';
$password = "Admin@123#";
$dbName = 'd-pharm';
try {
    $pdo = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUsername, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Define your API endpoint
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Fetch data from the database
    $stmt = $pdo->query("SELECT * FROM backup");
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Return data as JSON
    header('Content-Type: application/json');
    echo json_encode($data);
} else {
    // Handle unsupported HTTP methods
    http_response_code(405);
    echo json_encode(array("message" => "Method Not Allowed"));
}
?>